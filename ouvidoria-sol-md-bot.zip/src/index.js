require("dotenv").config();

const fs = require("node:fs");
const path = require("node:path");

const {
  Client,
  GatewayIntentBits,
  Partials,
  PermissionsBitField,
  ChannelType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  EmbedBuilder,
  SlashCommandBuilder,
  REST,
  Routes,
  Events,
} = require("discord.js");

const TOKEN = process.env.DISCORD_TOKEN;
const GUILD_ID = process.env.GUILD_ID;
const SOL_ID = process.env.SOL_USER_ID;
const MD_ID = process.env.MD_USER_ID;
const CATEGORY_ID = process.env.OUVIDORIA_CATEGORY_ID || null;
const LOG_CHANNEL_ID = process.env.LOG_CHANNEL_ID || null;

if (!TOKEN || !GUILD_ID || !SOL_ID || !MD_ID) {
  console.error("❌ Preencha DISCORD_TOKEN, GUILD_ID, SOL_USER_ID e MD_USER_ID no .env");
  process.exit(1);
}

const DATA_FILE = path.join(__dirname, "..", "data", "protocol.json");

function readProtocol() {
  try {
    const value = Number(fs.readFileSync(DATA_FILE, "utf8").trim());
    return Number.isFinite(value) && value > 0 ? value : 1;
  } catch {
    return 1;
  }
}

function saveProtocol(value) {
  fs.writeFileSync(DATA_FILE, String(value), "utf8");
}

let nextProtocol = readProtocol();

const COUPLE = {
  [SOL_ID]: { name: "Sol", nick: "Ruivinha de Marte" },
  [MD_ID]: { name: "MD", nick: "Carioca" },
};

const CATEGORIES = {
  ciumes: {
    label: "💚 Ciúmes",
    title: "Ciúmes detectado",
    reply:
      "📞 Setor de Ciúmes informa: a Ouvidoria analisou o caso e constatou excesso de sentimentos e falta de disfarce. Recomenda-se conversar, parar de provocar e lembrar que ninguém aqui é de ferro. 💚",
  },
  briga: {
    label: "💥 Briga",
    title: "Briga registrada",
    reply:
      "📞 Atenção, casal: o protocolo de briga foi aberto. A central recomenda baixar o tom, explicar o que aconteceu e evitar o clássico 'tanto faz' que claramente significa 'não tanto faz'.",
  },
  orgulho: {
    label: "😤 Orgulho",
    title: "Orgulho em análise",
    reply:
      "📞 O setor responsável informa: dois orgulhos grandes ocupam espaço demais no mesmo ticket. Um dos envolvidos deverá ceder antes que a central precise mandar um boleto de saudade.",
  },
  seco: {
    label: "🧊 Ficou seco",
    title: "Atendimento seco",
    reply:
      "📞 Foi identificado o famoso atendimento 'kk', 'sim' e 'tá'. A recomendação oficial é: conversar direito, porque ninguém consegue resolver uma relação por monossílabos.",
  },
  saudade: {
    label: "🥺 Saudade",
    title: "Saudade disfarçada",
    reply:
      "📞 Diagnóstico preliminar: isso tem 97% de chance de ser saudade fantasiada de implicância. A central recomenda uma conversa, uma risada e, se possível, parar de fingir que não sente falta.",
  },
  reconciliacao: {
    label: "🤝 Reconciliação",
    title: "Reconciliação solicitada",
    reply:
      "📞 Protocolo de reconciliação aberto. Sol e MD deverão lembrar que a conexão deles começou na zoeira e que, quando conversam de verdade, conseguem voltar ao normal.",
  },
};

function safeChannelName(name) {
  return name
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9-]/g, "-")
    .replace(/-+/g, "-")
    .slice(0, 45);
}

function buildPanel() {
  const embed = new EmbedBuilder()
    .setTitle("📞❤️ OUVIDORIA OFICIAL — SOL & MD")
    .setDescription(
      [
        "**Central de Atendimento ao Casal mais teimoso de Nárnia**",
        "",
        "Está tendo uma crise de ciúmes?",
        "Alguém ficou seco?",
        "O orgulho tomou conta?",
        "Ou os dois estão fingindo que não estão com saudade?",
        "",
        "🎫 Clique abaixo para abrir uma reclamação.",
        "A central emitirá um protocolo e abrirá um atendimento privado.",
      ].join("\n")
    )
    .setFooter({ text: "Ouvidoria Sol & MD • Atendimento 24h enquanto houver drama" });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("ouvidoria_abrir")
      .setLabel("Abrir reclamação")
      .setEmoji("🎫")
      .setStyle(ButtonStyle.Primary)
  );

  return { embeds: [embed], components: [row] };
}

function buildCategoryRows() {
  const entries = Object.entries(CATEGORIES);
  const rows = [];

  for (let i = 0; i < entries.length; i += 3) {
    const row = new ActionRowBuilder();

    for (const [key, value] of entries.slice(i, i + 3)) {
      row.addComponents(
        new ButtonBuilder()
          .setCustomId(`cat_${key}`)
          .setLabel(value.label.replace(/^.\s*/, ""))
          .setEmoji(value.label.slice(0, 2).trim())
          .setStyle(key === "briga" ? ButtonStyle.Danger : ButtonStyle.Secondary)
      );
    }

    rows.push(row);
  }

  return rows;
}

function buildModal(category) {
  const modal = new ModalBuilder()
    .setCustomId(`reclamacao_${category}`)
    .setTitle(`Ouvidoria • ${CATEGORIES[category].title}`);

  const assunto = new TextInputBuilder()
    .setCustomId("assunto")
    .setLabel("Quem está reclamando?")
    .setPlaceholder("Ex.: Sol reclamando do MD")
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setMaxLength(100);

  const descricao = new TextInputBuilder()
    .setCustomId("descricao")
    .setLabel("Conte o que aconteceu")
    .setPlaceholder("Escreva sua reclamação...")
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true)
    .setMinLength(3)
    .setMaxLength(1500);

  const provas = new TextInputBuilder()
    .setCustomId("provas")
    .setLabel("Tem provas? (opcional)")
    .setPlaceholder("Print, contexto, 'ele ficou seco', etc.")
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(false)
    .setMaxLength(800);

  modal.addComponents(
    new ActionRowBuilder().addComponents(assunto),
    new ActionRowBuilder().addComponents(descricao),
    new ActionRowBuilder().addComponents(provas)
  );

  return modal;
}

function getTicketControlRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("resolver_ticket")
      .setLabel("Resolver a briga")
      .setEmoji("🤝")
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId("fechar_ticket")
      .setLabel("Fechar ticket")
      .setEmoji("🔒")
      .setStyle(ButtonStyle.Danger)
  );
}

async function createTicket(interaction, category, assunto, descricao, provas) {
  const protocol = String(nextProtocol).padStart(4, "0");
  nextProtocol += 1;
  saveProtocol(nextProtocol);

  const guild = interaction.guild;
  const overwrites = [
    {
      id: guild.roles.everyone.id,
      deny: [PermissionsBitField.Flags.ViewChannel],
    },
    {
      id: SOL_ID,
      allow: [
        PermissionsBitField.Flags.ViewChannel,
        PermissionsBitField.Flags.SendMessages,
        PermissionsBitField.Flags.ReadMessageHistory,
      ],
    },
    {
      id: MD_ID,
      allow: [
        PermissionsBitField.Flags.ViewChannel,
        PermissionsBitField.Flags.SendMessages,
        PermissionsBitField.Flags.ReadMessageHistory,
      ],
    },
    {
      id: interaction.client.user.id,
      allow: [
        PermissionsBitField.Flags.ViewChannel,
        PermissionsBitField.Flags.SendMessages,
        PermissionsBitField.Flags.ReadMessageHistory,
        PermissionsBitField.Flags.ManageChannels,
      ],
    },
  ];

  const channel = await guild.channels.create({
    name: safeChannelName(`ticket-${protocol}-${interaction.user.username}`),
    type: ChannelType.GuildText,
    parent: CATEGORY_ID || undefined,
    topic: `Ouvidoria Sol & MD • Protocolo #${protocol} • Categoria: ${category}`,
    permissionOverwrites: overwrites,
  });

  const data = CATEGORIES[category];

  const embed = new EmbedBuilder()
    .setTitle(`📞 PROTOCOLO #${protocol} — ${data.title}`)
    .setDescription(
      [
        `**Reclamante:** ${interaction.user}`,
        `**Assunto:** ${assunto}`,
        "",
        `**Reclamação:**`,
        descricao,
        provas ? `\n**Provas/contexto:**\n${provas}` : "",
        "",
        data.reply,
      ].join("\n")
    )
    .setFooter({ text: "Ouvidoria Oficial Sol & MD • Nárnia" });

  await channel.send({
    content: `${interaction.user} 💌 **Seu atendimento foi aberto.** Sol e MD estão oficialmente convocados.`,
    embeds: [embed],
    components: [getTicketControlRow()],
  });

  await channel.send(
    "💬 **Agora os dois podem conversar normalmente neste ticket.** A central está de olho no drama."
  );

  await interaction.reply({
    content: `✅ Reclamação registrada! Seu protocolo é **#${protocol}**.\n🎫 ${channel}`,
    ephemeral: true,
  });

  return { channel, protocol };
}

async function closeTicket(channel, closedBy) {
  if (!channel || channel.type !== ChannelType.GuildText) return;

  if (LOG_CHANNEL_ID) {
    const log = channel.guild.channels.cache.get(LOG_CHANNEL_ID);
    if (log) {
      await log.send(
        `🔒 **Ticket encerrado**\nProtocolo: **${channel.topic?.match(/#(\\d+)/)?.[1] || "?"}**\nCanal: ${channel.name}\nEncerrado por: ${closedBy}`
      ).catch(() => {});
    }
  }

  await channel.send(`🔒 Atendimento encerrado por ${closedBy}. A Ouvidoria agradece a cooperação. ❤️`);
  setTimeout(() => channel.delete("Ouvidoria Sol & MD — ticket encerrado").catch(() => {}), 2500);
}

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent],
  partials: [Partials.Channel],
});

const commands = [
  new SlashCommandBuilder()
    .setName("ouvidoria")
    .setDescription("Publica o painel da Ouvidoria Sol & MD."),
  new SlashCommandBuilder()
    .setName("fechar")
    .setDescription("Fecha o ticket de ouvidoria atual."),
  new SlashCommandBuilder()
    .setName("protocolo")
    .setDescription("Mostra o próximo protocolo da Ouvidoria."),
].map((command) => command.toJSON());

async function registerCommands() {
  const rest = new REST({ version: "10" }).setToken(TOKEN);
  await rest.put(Routes.applicationGuildCommands(client.user.id, GUILD_ID), {
    body: commands,
  });
  console.log("✅ Comandos registrados no servidor.");
}

client.once(Events.ClientReady, async (readyClient) => {
  console.log(`🤖 Bot conectado como ${readyClient.user.tag}`);
  try {
    await registerCommands();
  } catch (error) {
    console.error("❌ Erro ao registrar comandos:", error);
  }
});

client.on(Events.InteractionCreate, async (interaction) => {
  try {
    if (!interaction.guild) {
      if (interaction.isRepliable()) {
        await interaction.reply({
          content: "❤️ A Ouvidoria funciona dentro do servidor do casal.",
          ephemeral: true,
        });
      }
      return;
    }

    if (interaction.isChatInputCommand()) {
      if (![SOL_ID, MD_ID].includes(interaction.user.id)) {
        await interaction.reply({
          content: "📞 Desculpe, esta central é exclusiva para Sol & MD. Nárnia não aceita terceiros neste protocolo. 😂",
          ephemeral: true,
        });
        return;
      }

      if (interaction.commandName === "ouvidoria") {
        await interaction.channel.send(buildPanel());
        await interaction.reply({
          content: "✅ Painel da Ouvidoria publicado.",
          ephemeral: true,
        });
      }

      if (interaction.commandName === "protocolo") {
        await interaction.reply({
          content: `📋 Próximo protocolo disponível: **#${String(nextProtocol).padStart(4, "0")}**`,
          ephemeral: true,
        });
      }

      if (interaction.commandName === "fechar") {
        if (!interaction.channel.name.startsWith("ticket-")) {
          await interaction.reply({
            content: "🔒 Este comando só pode ser usado dentro de um ticket.",
            ephemeral: true,
          });
          return;
        }
        await interaction.reply({ content: "🔒 Encerrando atendimento..." });
        await closeTicket(interaction.channel, interaction.user);
      }
      return;
    }

    if (interaction.isButton()) {
      if (![SOL_ID, MD_ID].includes(interaction.user.id)) {
        await interaction.reply({
          content: "📞 Esta Ouvidoria é exclusiva para Sol & MD. 😂",
          ephemeral: true,
        });
        return;
      }

      if (interaction.customId === "ouvidoria_abrir") {
        await interaction.reply({
          content: "👇 Escolha o motivo da reclamação:",
          components: buildCategoryRows(),
          ephemeral: true,
        });
        return;
      }

      if (interaction.customId.startsWith("cat_")) {
        const category = interaction.customId.replace("cat_", "");
        if (!CATEGORIES[category]) return;
        await interaction.showModal(buildModal(category));
        return;
      }

      if (interaction.customId === "resolver_ticket") {
        if (!interaction.channel.name.startsWith("ticket-")) {
          await interaction.reply({ content: "🤨 Isso aqui não parece um ticket.", ephemeral: true });
          return;
        }

        const embed = new EmbedBuilder()
          .setTitle("🤝 CASO ENCAMINHADO PARA RECONCILIAÇÃO")
          .setDescription(
            [
              "📞 A Ouvidoria acaba de intervir.",
              "",
              "Sol e MD ficam oficialmente proibidos de prolongar uma briga por orgulho.",
              "Vocês já sabem conversar, rir e voltar ao normal.",
              "",
              "**Procedimento obrigatório:**",
              "1. Cada um explica o que sentiu.",
              "2. Cada um escuta o outro.",
              "3. Se houver pedido de desculpas, ele deve ser aceito.",
              "4. Nada de 'tanto faz' quando claramente não é tanto faz.",
              "",
              "❤️ **Ticket em status: quase resolvido.**",
            ].join("\n")
          );

        await interaction.channel.send({ embeds: [embed] });
        await interaction.reply({ content: "🤝 Reconciliação registrada.", ephemeral: true });
        return;
      }

      if (interaction.customId === "fechar_ticket") {
        if (!interaction.channel.name.startsWith("ticket-")) {
          await interaction.reply({ content: "🔒 Este botão só funciona dentro de um ticket.", ephemeral: true });
          return;
        }

        await interaction.reply({ content: "🔒 Fechando o ticket..." });
        await closeTicket(interaction.channel, interaction.user);
        return;
      }
    }

    if (interaction.isModalSubmit()) {
      if (![SOL_ID, MD_ID].includes(interaction.user.id)) {
        await interaction.reply({
          content: "📞 Esta Ouvidoria é exclusiva para Sol & MD.",
          ephemeral: true,
        });
        return;
      }

      if (interaction.customId.startsWith("reclamacao_")) {
        const category = interaction.customId.replace("reclamacao_", "");
        const assunto = interaction.fields.getTextInputValue("assunto");
        const descricao = interaction.fields.getTextInputValue("descricao");
        const provas = interaction.fields.getTextInputValue("provas") || "";

        await createTicket(interaction, category, assunto, descricao, provas);
      }
    }
  } catch (error) {
    console.error("❌ Erro na interação:", error);
    if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
      await interaction.reply({
        content: "❌ A central teve um problema técnico. Tente novamente.",
        ephemeral: true,
      }).catch(() => {});
    }
  }
});

// Respostas automáticas simples dentro dos tickets.
const cooldowns = new Map();

client.on(Events.MessageCreate, async (message) => {
  if (message.author.bot || !message.guild) return;
  if (!message.channel.name?.startsWith("ticket-")) return;
  if (![SOL_ID, MD_ID].includes(message.author.id)) return;

  const now = Date.now();
  const last = cooldowns.get(message.channel.id) || 0;
  if (now - last < 20000) return;

  const text = message.content.toLowerCase();
  let reply = null;

  if (/(ciume|ciúme|ciumes|ciúmes|ciumento|ciumenta)/i.test(text)) {
    reply = "📞 **Setor de Ciúmes:** a central recebeu a denúncia. Agora os dois precisam explicar o que sentiram sem transformar o ticket em campeonato de indiretas. 😂";
  } else if (/(saudade|sinto falta|faz falta)/i.test(text)) {
    reply = "📞 **Setor de Saudade:** identificado sentimento escondido. A recomendação oficial é parar de fingir costume e conversar. 🥺❤️";
  } else if (/(desculpa|foi mal|perd[aã]o)/i.test(text)) {
    reply = "📞 **Setor de Reconciliação:** pedido de desculpas detectado. Favor analisar com carinho antes de responder com um simples 'ok'. 🤝";
  } else if (/(tanto faz|tá bom|ta bom|sim|ok|beleza)/i.test(text) && text.length < 40) {
    reply = "📞 **Alerta de resposta seca:** a central solicita uma frase completa. Este relacionamento não será resolvido por monossílabos. 😂";
  }

  if (reply) {
    cooldowns.set(message.channel.id, now);
    await message.channel.send(reply).catch(() => {});
  }
});

client.login(TOKEN);
