# ❤️📞 Ouvidoria Oficial — Sol & MD

Bot de Discord personalizado para a brincadeira da "Ouvidoria do Casal".

## O que ele faz

- `/ouvidoria` publica o painel da ouvidoria.
- Botão `🎫 Abrir reclamação` abre um formulário.
- A reclamação recebe um protocolo automático.
- O bot cria um canal privado de ticket.
- Apenas Sol, MD e o bot conseguem ver o ticket.
- Categorias: ciúmes, briga, orgulho, ficou seco, saudade e reconciliação.
- O bot responde automaticamente com mensagens personalizadas.
- Botão `🤝 Resolver a briga` envia uma mensagem de reconciliação.
- `/fechar` fecha o ticket atual e, se configurado, envia um log.
- `/protocolo` mostra o número do protocolo atual.

## Requisitos

O projeto foi preparado para Node.js 24.17+ e discord.js 14.x. A documentação atual do discord.js informa Node.js 24.17+ como requisito. 

## 1. Criar o bot

1. Entre no Developer Portal do Discord.
2. Crie uma Application.
3. Abra a aba Bot e crie o bot.
4. Copie o token para o `.env`.
5. Em OAuth2/Installation, adicione os escopos `bot` e `applications.commands`.
6. Dê ao bot, no servidor, pelo menos:
   - View Channels
   - Send Messages
   - Read Message History
   - Manage Channels
   - Embed Links

Nunca publique o token do bot.

## 2. Pegar os IDs

No Discord, ative o Modo Desenvolvedor em Configurações > Avançado.

Depois:
- clique com botão direito no servidor -> Copiar ID -> `GUILD_ID`
- clique com botão direito no perfil da Sol -> Copiar ID -> `SOL_USER_ID`
- clique com botão direito no perfil do MD -> Copiar ID -> `MD_USER_ID`
- opcionalmente clique com botão direito na categoria -> Copiar ID -> `OUVIDORIA_CATEGORY_ID`
- opcionalmente clique com botão direito no canal de logs -> Copiar ID -> `LOG_CHANNEL_ID`

## 3. Configurar

Copie `.env.example` para `.env` e preencha os IDs e o token.

## 4. Instalar e iniciar

No terminal dentro da pasta do projeto:

```bash
npm install
npm start
```

Quando aparecer `Bot conectado`, o bot estará online.

## 5. Publicar o painel

No canal desejado, use:

```text
/ouvidoria
```

Depois é só clicar em `🎫 Abrir reclamação`.

## Observação

Os comandos são registrados diretamente no servidor informado em `GUILD_ID`, então aparecem rapidamente nesse servidor.
